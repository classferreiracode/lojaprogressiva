<template>
  <div>
    <section class="py-12 container mx-auto">
      <h1 class="text-3xl font-bold mb-6">Nossa Loja</h1>
      <p>Aqui você encontra nossos produtos!</p>
    </section>
  </div>
</template>

<script setup>
</script>