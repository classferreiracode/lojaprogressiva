<template>
  <div>
    <!-- Hero Section -->
    <section class="bg-pink-50 py-12 text-center">
      <h1 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">Bem-vinda à Progressiva Fashion</h1>
      <p class="text-gray-600 mb-6">Produtos para realçar sua beleza todos os dias.</p>
      <RouterLink to="/loja" class="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-8 rounded-full transition">
        Ver Produtos
      </RouterLink>
    </section>

    <!-- Categorias -->
    <section class="py-12 container mx-auto">
      <h2 class="text-3xl font-bold text-center mb-8">Categorias</h2>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-lg shadow p-4 text-center hover:bg-pink-50 transition">
          <div class="text-pink-600 text-3xl mb-2">
            <i class="fas fa-spa"></i>
          </div>
          <p class="font-medium">Tratamento</p>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center hover:bg-pink-50 transition">
          <div class="text-pink-600 text-3xl mb-2">
            <i class="fas fa-paint-brush"></i>
          </div>
          <p class="font-medium">Maquiagem</p>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center hover:bg-pink-50 transition">
          <div class="text-pink-600 text-3xl mb-2">
            <i class="fas fa-spray-can"></i>
          </div>
          <p class="font-medium">Perfumes</p>
        </div>
        <div class="bg-white rounded-lg shadow p-4 text-center hover:bg-pink-50 transition">
          <div class="text-pink-600 text-3xl mb-2">
            <i class="fas fa-wind"></i>
          </div>
          <p class="font-medium">Acessórios</p>
        </div>
      </div>
    </section>

    <!-- Produtos em Destaque -->
    <section class="py-12 bg-gray-50">
      <div class="container mx-auto">
        <h2 class="text-3xl font-bold text-center mb-8">Produtos em Destaque</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <div v-for="p in produtos" :key="p.id" class="bg-white rounded-lg shadow overflow-hidden">
            <img :src="p.image" :alt="p.name" class="w-full h-48 object-cover">
            <div class="p-4">
              <h3 class="font-medium mb-1">{{ p.name }}</h3>
              <p class="text-sm text-gray-500 mb-2">{{ p.description }}</p>
              <div class="flex justify-between items-center">
                <span class="text-pink-600 font-bold">R$ {{ p.price }}</span>
                <button class="text-pink-500 hover:text-pink-700">
                  <i class="fas fa-shopping-cart"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Call to Action -->
    <section class="py-12 bg-gradient-to-r from-pink-600 to-pink-400 text-white text-center">
      <h2 class="text-3xl font-bold mb-4">Grupo vip da Progressiva Fashion exclusivamente para vocês, diretamente no WhatsApp</h2>
      <a href="https://chat.whatsapp.com/Fvp41d8vrTaBw81BxGAWk1" target="_blank" class="bg-white text-pink-600 font-bold py-3 px-8 rounded-full hover:bg-gray-100 transition">
        Ir para o Grupo VIP
      </a>
    </section>
  </div>
</template>

<script setup>
import { RouterLink } from 'vue-router'

const produtos = [
  {
    id: 1,
    name: 'Shampoo Revitalizante',
    description: 'Para cabelos danificados',
    price: '39,90',
    image: 'https://images.unsplash.com/photo-1556228578323-dc24e1044eeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=687&q=80'
  },
  {
    id: 2,
    name: 'Kit Brilho Extremo',
    description: 'Shampoo + Máscara',
    price: '89,90',
    image: 'https://images.unsplash.com/photo-1625772452859-1c03d5bf1137?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80'
  },
  {
    id: 3,
    name: 'Perfume Florais',
    description: 'Fragrância exclusiva',
    price: '129,90',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&auto=format&fit=crop&w=688&q=80'
  },
  {
    id: 4,
    name: 'Base Líquida',
    description: 'Cobertura natural',
    price: '59,90',
    image: 'https://images.unsplash.com/photo-1571781926291-c477ebfd024b?ixlib=rb-4.0.3&auto=format&fit=crop&w=688&q=80'
  }
]
</script>
